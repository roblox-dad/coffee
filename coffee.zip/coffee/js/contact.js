 // JavaScript function to toggle the navigation menu
function openNavbar() {
	const navMenu = document.getElementById("nav-menu");
	navMenu.classList.toggle("active");
}
